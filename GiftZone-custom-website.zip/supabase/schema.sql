-- Run in Supabase SQL editor only after reviewing. Enable RLS on every table.
create extension if not exists pgcrypto;
create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(),
 created_at timestamptz not null default now(),
 customer_email text not null,
 product_slug text not null,
 product_name text not null,
 denomination numeric(10,2) not null check (denomination > 0),
 currency text not null default 'EUR',
 region text not null,
 payment_status text not null default 'pending' check (payment_status in ('pending','paid','failed','refunded')),
 fulfillment_status text not null default 'unfulfilled' check (fulfillment_status in ('unfulfilled','processing','fulfilled','cancelled')),
 payment_provider_reference text,
 fulfillment_note text,
 fulfilled_at timestamptz
);
create table if not exists public.admin_audit_log (
 id uuid primary key default gen_random_uuid(),
 created_at timestamptz not null default now(),
 actor_user_id uuid,
 order_id uuid references public.orders(id),
 action text not null,
 note text
);
alter table public.orders enable row level security;
alter table public.admin_audit_log enable row level security;
-- No public policies are intentionally added. Add narrowly scoped policies only
-- after implementing authenticated customer order access and verified admin roles.
-- Never store raw gift card codes in a table readable by the browser.
