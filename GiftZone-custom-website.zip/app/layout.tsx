import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "GiftZone — Digital Gift Cards, Delivered",
  description: "Shop digital gift cards from the brands you love. Secure checkout and manual email delivery.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}