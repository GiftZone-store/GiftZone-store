import Link from "next/link";
import { notFound } from "next/navigation";
import { Header,Footer } from "@/components/site";
import { products,denominations } from "@/lib/products";
import ProductBuy from "./product-buy";
export function generateStaticParams(){return products.map(p=>({slug:p.slug}));}
export default async function ProductPage({params}:{params:Promise<{slug:string}>}){
 const {slug}=await params; const p=products.find(x=>x.slug===slug); if(!p) notFound();
 return <><Header/><main className="wrap page"><Link href="/" className="muted">← All gift cards</Link><div style={{display:"grid",gridTemplateColumns:"minmax(0,1fr) minmax(0,1.1fr)",gap:45,marginTop:28}}><div className="brand-art" style={{height:300,fontSize:42,background:p.color}}>{p.mark}</div><div><span className="tag">DIGITAL GIFT CARD</span><h1>{p.name}</h1><p className="muted">{p.desc}</p><div className="notice">Important: Gift card availability, currency and redemption rules vary by country. Confirm the recipient's country and the card's region before purchasing.</div><ProductBuy slug={p.slug} name={p.name} denominations={denominations}/><p className="muted" style={{fontSize:12,marginTop:18}}>Manual delivery: after your payment is verified, an administrator checks your order and emails your code. Delivery is not instant.</p></div></div></main><Footer/></>
}