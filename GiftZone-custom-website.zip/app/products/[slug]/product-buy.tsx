"use client";
import {useState} from "react";
import {useRouter} from "next/navigation";
export default function ProductBuy({slug,name,denominations}:{slug:string;name:string;denominations:number[]}){
 const [value,setValue]=useState(20); const [region,setRegion]=useState(""); const [email,setEmail]=useState(""); const router=useRouter();
 function add(){const item={slug,name,value,region,email};localStorage.setItem("giftzone_cart",JSON.stringify(item));router.push("/cart");}
 return <><strong>Choose value</strong><div className="denoms">{denominations.map(n=><button key={n} className={`denom ${value===n?"active":""}`} onClick={()=>setValue(n)}>€{n}</button>)}</div><div className="field"><label>Recipient's country / region</label><input value={region} onChange={e=>setRegion(e.target.value)} placeholder="e.g. Netherlands, United States"/></div><div className="field"><label>Email for delivery</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></div><button className="primary" onClick={add} disabled={!region.trim()||!email.includes("@")}>Add to cart · €{value}</button></>
}